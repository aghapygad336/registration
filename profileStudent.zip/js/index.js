$(document).ready(function(){
  $('#max').click(function(){
    alert('Logout');
  })
});